const { ipcRenderer } = require('electron');

// Define the types array globally so it's accessible everywhere
const types = ['any', 'int', 'float', 'str', 'list', 'dict', 'bool'];

document.addEventListener('DOMContentLoaded', () => {
  const tabs = document.querySelectorAll('.tab');
  const testContent = document.getElementById('test-content');
  const editorContent = document.getElementById('editor-content');
  const addTestBtn = document.getElementById('add-test-btn');
  const exportTestBtn = document.getElementById('export-test-btn');
  const testList = document.getElementById('test-list-ul');
  const functionInput = document.getElementById('function-input');
  const themeToggleBtn = document.getElementById('theme-toggle-btn');

  // Ensure the button is defined and not duplicated
  if (!themeToggleBtn) {
    console.error('Dark mode button not found');
    return;
  }

  // Load theme preference from localStorage
  const currentTheme = localStorage.getItem('theme') || 'light';
  if (currentTheme === 'dark') {
    document.body.classList.add('dark-mode');
    themeToggleBtn.textContent = '☀️'; // Sun icon for light mode
  } else {
    themeToggleBtn.textContent = '🌙'; // Moon icon for dark mode
  }

  // Toggle theme and save preference when button is clicked
  themeToggleBtn.addEventListener('click', () => {
    document.body.classList.toggle('dark-mode');
    const isDarkMode = document.body.classList.contains('dark-mode');
    themeToggleBtn.textContent = isDarkMode ? '☀️' : '🌙'; // Toggle between sun and moon icons
    localStorage.setItem('theme', isDarkMode ? 'dark' : 'light');
  });

  // Tab switching logic
  tabs.forEach((tab) => {
    tab.addEventListener('click', () => {
      tabs.forEach((t) => t.classList.remove('active'));
      tab.classList.add('active');

      if (tab.id === 'test-tab') {
        testContent.style.display = 'block';
        editorContent.style.display = 'none';
      } else {
        testContent.style.display = 'none';
        editorContent.style.display = 'block';
      }
    });
  });

  testContent.style.display = 'block';
  tabs[0].classList.add('active');

  // Function to add a parameter row with type selector
  function addParameterRow(paramList, paramValue = '', paramType = 'any') {
    const paramRow = document.createElement('div');
    paramRow.className = 'param-row';

    const paramInput = document.createElement('input');
    paramInput.type = 'text';
    paramInput.placeholder = 'Parameter...';
    paramInput.value = paramValue;

    const paramTypeSelect = document.createElement('select');
    paramTypeSelect.className = 'param-type-select';
    types.forEach((type) => {
      const option = document.createElement('option');
      option.value = type;
      option.textContent = type;
      paramTypeSelect.appendChild(option);
    });
    paramTypeSelect.value = paramType;

    const removeParamBtn = document.createElement('button');
    removeParamBtn.textContent = 'Remove';
    removeParamBtn.className = 'remove-param-btn';
    removeParamBtn.addEventListener('click', () => paramRow.remove());

    paramRow.appendChild(paramInput);
    paramRow.appendChild(paramTypeSelect);
    paramRow.appendChild(removeParamBtn);

    paramList.appendChild(paramRow);
  }

  // Function to add a test case with parameter list and output
  function addTestCase(testParams = [], expectedOutput = '', expectedType = 'any') {
    const li = document.createElement('li');
    li.className = 'test-input-group';

    // Parameter List Container
    const paramList = document.createElement('div');
    paramList.className = 'param-list';

    // Button to add parameters
    const addParamBtn = document.createElement('button');
    addParamBtn.textContent = 'Add Parameter';
    addParamBtn.className = 'add-param-btn';
    addParamBtn.addEventListener('click', () => addParameterRow(paramList));

    // Add initial parameters if any
    testParams.forEach(([paramValue, paramType]) => addParameterRow(paramList, paramValue, paramType));

    // Row for expected output and type dropdown
    const testRow = document.createElement('div');
    testRow.className = 'test-row';

    const expectedOutputInput = document.createElement('input');
    expectedOutputInput.type = 'text';
    expectedOutputInput.placeholder = 'Expected output...';
    expectedOutputInput.value = expectedOutput;

    const outputTypeSelect = document.createElement('select');
    outputTypeSelect.className = 'output-type-select';
    types.forEach((type) => {
      const option = document.createElement('option');
      option.value = type;
      option.textContent = type;
      outputTypeSelect.appendChild(option);
    });
    outputTypeSelect.value = expectedType;

    // Append input and dropdown to the same row
    testRow.appendChild(expectedOutputInput);
    testRow.appendChild(outputTypeSelect);

    const removeTestBtn = document.createElement('button');
    removeTestBtn.textContent = 'Remove';
    removeTestBtn.className = 'remove-btn';
    removeTestBtn.addEventListener('click', () => li.remove());

    // Append everything to the list item
    li.appendChild(paramList);
    li.appendChild(addParamBtn);
    li.appendChild(testRow); // Append the new row with the input and dropdown
    li.appendChild(removeTestBtn);
    testList.appendChild(li);
  }

  addTestCase(); // Add an initial test case

  addTestBtn.addEventListener('click', () => addTestCase());

  // Event listener for the export tests button
  exportTestBtn.addEventListener('click', async () => {
    console.log('Export button clicked'); // Log to confirm event triggered
    await saveTests(); // Call the saveTests function directly
  });

  // Function to collect data and save tests
  async function saveTests() {
    console.log('Initiating save tests...'); // Log to ensure the process starts
    const functionName = functionInput.value || 'function_name';
    const tests = {};

    testList.querySelectorAll('li').forEach((li) => {
      const params = Array.from(li.querySelectorAll('.param-row')).map((row) => {
        const paramValue = row.querySelector('input[type="text"]').value;
        const paramType = row.querySelector('.param-type-select').value;
        return [paramValue, paramType];
      });

      const expectedOutput = li.querySelector('.test-row input[type="text"]').value;
      const expectedType = li.querySelector('.output-type-select').value;

      tests[JSON.stringify(params)] = [expectedOutput, expectedType];
    });

    const jsonData = {
      testfunc: functionName,
      tests: tests,
    };

    try {
      const result = await ipcRenderer.invoke('save-json-data', jsonData);
      console.log(result); // Log the success message from the main process
    } catch (error) {
      console.error('Error saving data:', error); // Log error if any occurs
    }
  }

  // Load tests handler
  ipcRenderer.on('load-tests', async () => {
    try {
      const jsonData = await ipcRenderer.invoke('load-json-data');
      if (jsonData) {
        functionInput.value = jsonData.testfunc || '';
        testList.innerHTML = ''; // Clear existing tests

        for (const [paramStr, [output, type]] of Object.entries(jsonData.tests)) {
          const params = JSON.parse(paramStr);
          addTestCase(params, output, type);
        }

        // Switch to the editor tab
        tabs.forEach((t) => t.classList.remove('active'));
        document.getElementById('editor-tab').classList.add('active');
        testContent.style.display = 'none';
        editorContent.style.display = 'block';
      }
    } catch (error) {
      console.error('Error loading data:', error);
    }
  });
});
